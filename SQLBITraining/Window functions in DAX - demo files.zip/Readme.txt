Every lecture (Mxx.Lxx) of the video course has a corresponding DAX file with the DAX code used in the demos.
You can open the module file and repeat the same operations step by step as in the video.
The queries can be executed on the "Window functions in DAX.pbix" file, unless there are specific demo files for the lecture.
